"""Explicit one-shot CLI."""
import argparse
import json
import sys

from . import MarineTrafficClient, MarineTrafficError, __version__
from .client import validate_ship_id


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Unofficial MarineTraffic single-position query")
    parser.add_argument("--version", action="version", version=__version__)
    commands = parser.add_subparsers(dest="command", required=True)
    position = commands.add_parser("position", help="Send one GET and return the original JSON")
    position.add_argument("ship_id", type=validate_ship_id)
    args = parser.parse_args(argv)
    try:
        with MarineTrafficClient() as client:
            result = client.get_position(args.ship_id)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except MarineTrafficError as exc:
        details = {"error": type(exc).__name__, "message": str(exc)}
        for key in ("status_code", "retry_after"):
            value = getattr(exc, key, None)
            if value is not None:
                details[key] = value
        print(json.dumps(details, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
