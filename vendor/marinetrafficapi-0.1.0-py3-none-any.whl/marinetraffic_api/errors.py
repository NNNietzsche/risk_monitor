"""Basic errors; no scheduling or response-body logging."""


class MarineTrafficError(Exception):
    """Base class for SDK operational errors."""


class TransportError(MarineTrafficError):
    """Network, TLS or timeout failure."""


class HTTPError(MarineTrafficError):
    """Actual HTTP status and raw Retry-After value for the caller to handle."""

    def __init__(self, status_code: int, retry_after: str | None = None):
        self.status_code = status_code
        self.retry_after = retry_after
        super().__init__(f"MarineTraffic returned HTTP {status_code}; no retry was performed.")


class InvalidResponseError(MarineTrafficError):
    """The response is not the expected vessel JSON object."""
