"""Minimal position client: one GET, return the upstream JSON dictionary."""
import json
import math
from typing import Any

from curl_cffi.const import CurlHttpVersion
from curl_cffi.requests import Session
from curl_cffi.requests.exceptions import RequestException

from .errors import HTTPError, InvalidResponseError, MarineTrafficError, TransportError

BASE_URL = "https://www.marinetraffic.com"


def validate_ship_id(value: int | str) -> int:
    if isinstance(value, str) and value.isascii() and value.isdecimal():
        if len(value) > 19:
            raise ValueError("ship_id must be a positive integer below 2**63.")
        value = int(value)
    if type(value) is not int or not 0 < value < 2**63:
        raise ValueError("ship_id must be a positive integer below 2**63 (not MMSI/IMO).")
    return value


def _reject_constant(value: str) -> None:
    raise ValueError(f"Non-standard JSON constant: {value}")


class MarineTrafficClient:
    """Synchronous client. Scheduling and rate control belong to the caller.

    Construction performs no requests. Reuse sequentially and close when done.
    Concurrent use of a client is not part of this experimental API's contract.
    """

    def __init__(self, *, timeout: float = 20):
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("timeout must be finite and positive.")
        self._timeout = float(timeout)
        self._session = Session(impersonate="chrome150", trust_env=False,
                                retry=0, allow_redirects=False)
        self._closed = False

    def get_position(self, ship_id: int | str) -> dict[str, Any]:
        """Return the full position JSON object without renaming its fields."""
        ship_id = validate_ship_id(ship_id)
        if self._closed:
            raise MarineTrafficError("Client is closed.")
        headers = {
            "accept": "application/json, text/plain, */*",
            "accept-language": "zh-CN,zh;q=0.9,en;q=0.8,ja;q=0.7",
            "x-requested-with": "XMLHttpRequest",
            "referer": f"{BASE_URL}/en/ais/details/ships/shipid:{ship_id}",
            "sec-fetch-dest": "empty", "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin", "cache-control": "no-cache",
            "pragma": "no-cache", "priority": "u=1, i",
        }
        try:
            response = self._session.get(
                f"{BASE_URL}/en/vessels/{ship_id}/position", headers=headers,
                timeout=self._timeout, allow_redirects=False,
                http_version=CurlHttpVersion.V2_0, accept_encoding="gzip, br",
            )
        except RequestException:
            raise TransportError("Network/TLS/timeout failure; no retry was performed.") from None
        response_headers = {k.lower(): v for k, v in response.headers.items()}
        if response.status_code != 200:
            raise HTTPError(response.status_code, response_headers.get("retry-after"))
        mime = response_headers.get("content-type", "").split(";", 1)[0].strip().lower()
        if mime != "application/json" and not (mime.startswith("application/") and mime.endswith("+json")):
            raise InvalidResponseError("Expected JSON but received another content type.")
        try:
            payload = json.loads(response.content, parse_constant=_reject_constant)
        except (ValueError, UnicodeError, RecursionError):
            raise InvalidResponseError("Response body is not valid JSON.") from None
        if not isinstance(payload, dict):
            raise InvalidResponseError("Expected a position JSON object.")
        if type(payload.get("shipId")) is not int or payload["shipId"] != ship_id:
            raise InvalidResponseError("Response vessel identity does not match ship_id.")
        return payload

    def close(self) -> None:
        if not self._closed:
            self._session.close()
            self._closed = True

    def __enter__(self) -> "MarineTrafficClient":
        if self._closed:
            raise MarineTrafficError("Client is closed.")
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
